package com.demo.methods;

/**
 *
 * @author m.dossa
 */
public interface IReverseString {
    void reverseString();
}
