package com.demo.methods;

/**
 *
 * @author m.dossa
 */
public interface IPrimeNumbers {

    void getPrimeNums();
}
